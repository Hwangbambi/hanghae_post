package com.example.homework.dto;

import lombok.Getter;

@Getter
public class CommentRequestDto {
    private String comment;
}